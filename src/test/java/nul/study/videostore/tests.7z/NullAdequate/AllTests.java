package nul.study.videostore.NullAdequate;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ Customer_NullAdequateTest.class, Movie_NullAdequateTest.class })
public class AllTests {

}
